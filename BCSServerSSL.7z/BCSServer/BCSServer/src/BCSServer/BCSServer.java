package BCSServer;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 *
 * @author Administrator
 */
public class BCSServer extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;
    static Object outputJTextArea;
    static Object textAreaServer;
    private Integer j2;
    UtilitiesFunctions utl = new UtilitiesFunctions();
    private BufferedReader inFromClient;
    private String clientSentence;

    /**
     * Creates new form NewJFrame
     */
    public BCSServer() {
        initComponents();

        EndRange.setVisible(false);
        StartRange.setVisible(false);
        OutputTraditionalMethodTextArea.setVisible(false);
        CalculateFactorial.setVisible(false);
        Calculate.setVisible(false);
        To.setVisible(false);
        FactorialResult.setVisible(false);
        EndRange.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                FactorialResult.setVisible(true);
                OutputTraditionalMethodTextArea.setText("");
                BigInteger factor = BigInteger.valueOf(1);
                Integer j1 = Integer.parseInt(BCSServer.StartRange.getText());
                System.out.println(j1);
                Integer j2 = Integer.parseInt(EndRange.getText());
                System.out.println(j1);
                if (j1 >= 0 && j2 >= j1) {
                    for (int j = j1; j <= j2; j++) {
                        FacCalculateThreadTraditionalMethod fct = new FacCalculateThreadTraditionalMethod(j, factor, OutputTraditionalMethodTextArea);
                        fct.start();
                        try {
                            fct.join();
                        } catch (InterruptedException ex) {
                            Logger.getLogger(BCSServer.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        try {
                            FacCalculateThreadTraditionalMethod.sleep(200);
                        } catch (InterruptedException ex) {
                            Logger.getLogger(BCSServer.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                } else {
                    OutputTraditionalMethodTextArea.append("Enter Correct Values!");
                }
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                //No value to perform
//                OutputTraditionalMethodTextArea.setText("");
//                BigInteger factor = BigInteger.valueOf(1);
//                Integer j1 = Integer.parseInt(BCSServer.StartRange.getText());
//                System.out.println(j1);
//                Integer j2 = Integer.parseInt(EndRange.getText());
//                System.out.println(j1);
//                if (j1 >= 0 && j2 >= j1) {
//                    for (int j = j1; j <= j2; j++) {
//                        FacCalculateThreadTraditionalMethod fct = new FacCalculateThreadTraditionalMethod(j, factor, OutputTraditionalMethodTextArea);
//                        fct.start();
//                        try {
//                            fct.join();
//                        } catch (InterruptedException ex) {
//                            Logger.getLogger(BCSServer.class.getName()).log(Level.SEVERE, null, ex);
//                        }
//                    }
//                } else {
//                    OutputTraditionalMethodTextArea.append("Enter Correct Values!");
//                }
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                FactorialResult.setVisible(true);
                OutputTraditionalMethodTextArea.setText("");
                BigInteger factor = BigInteger.valueOf(1);
                Integer j1 = Integer.parseInt(BCSServer.StartRange.getText());
                System.out.println(j1);
                Integer j2 = Integer.parseInt(EndRange.getText());
                System.out.println(j1);
                if (j1 >= 0 && j2 >= j1) {
                    for (int j = j1; j <= j2; j++) {
                        FacCalculateThreadTraditionalMethod fct = new FacCalculateThreadTraditionalMethod(j, factor, OutputTraditionalMethodTextArea);
                        fct.start();
                        try {
                            fct.join();
                        } catch (InterruptedException ex) {
                            Logger.getLogger(BCSServer.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                } else {
                    OutputTraditionalMethodTextArea.append("Enter Correct Values!");
                }
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        CalculateFactorial = new javax.swing.JLabel();
        EndRange = new javax.swing.JTextField();
        StartRange = new javax.swing.JTextField();
        To = new javax.swing.JLabel();
        Calculate = new javax.swing.JButton();
        OutputScrollBar = new javax.swing.JScrollPane();
        OutputTraditionalMethodTextArea = new javax.swing.JTextArea();
        PortValue = new javax.swing.JTextField();
        Listen = new javax.swing.JButton();
        FactorialResult = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("BCS Server");
        setResizable(false);

        CalculateFactorial.setText("Calculate Factorial");

        EndRange.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EndRangeActionPerformed(evt);
            }
        });
        EndRange.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                EndRangePropertyChange(evt);
            }
        });

        To.setText("   to");

        Calculate.setText("Calculate");
        Calculate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CalculateActionPerformed(evt);
            }
        });

        OutputTraditionalMethodTextArea.setColumns(20);
        OutputTraditionalMethodTextArea.setRows(5);
        OutputScrollBar.setViewportView(OutputTraditionalMethodTextArea);

        PortValue.setText("12345");

        Listen.setText("Listen");
        Listen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ListenActionPerformed(evt);
            }
        });

        FactorialResult.setText("Factorial Result");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(OutputScrollBar)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(PortValue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Listen))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(CalculateFactorial)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(StartRange, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(To, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(EndRange, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Calculate))
                    .addComponent(FactorialResult, javax.swing.GroupLayout.PREFERRED_SIZE, 509, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 843, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PortValue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Listen))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CalculateFactorial)
                    .addComponent(StartRange, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(To)
                    .addComponent(EndRange, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Calculate))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(FactorialResult)
                .addGap(1, 1, 1)
                .addComponent(OutputScrollBar, javax.swing.GroupLayout.DEFAULT_SIZE, 612, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void EndRangeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EndRangeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EndRangeActionPerformed

    @SuppressWarnings("deprecation")
    private void CalculateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CalculateActionPerformed
//        OutputTraditionalMethodTextArea.setText("");
//        BigInteger factor = BigInteger.valueOf(1);
//        Integer j1 = Integer.parseInt(StartRange.getText());
//        this.j2 = Integer.parseInt(EndRange.getText());
//        if (j1 >= 0 && j2 >= j1) {
//            for (int j = j1; j <= j2; j++) {
//                FacCalculateThreadTraditionalMethod fct = new FacCalculateThreadTraditionalMethod(j, factor, OutputTraditionalMethodTextArea);
//                fct.start();
//                try {
//                    fct.join();
//                } catch (InterruptedException ex) {
//                    Logger.getLogger(BCSServer.class.getName()).log(Level.SEVERE, null, ex);
//                }
//            }
//        } else {
//            OutputTraditionalMethodTextArea.append("Enter Correct Values!");
//        }
    }//GEN-LAST:event_CalculateActionPerformed

    private void ListenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ListenActionPerformed
        String portval = PortValue.getText();
        if (utl.isInteger(portval)) {
            if (utl.isOutOfRange(portval)) {
                try {
                    int portint = Integer.parseInt(portval);

                    String ksName = "herong.jks";
                    char ksPass[] = "HerongJKS".toCharArray();
                    char ctPass[] = "My1stKey".toCharArray();
                    KeyStore ks = KeyStore.getInstance("JKS");
                    InputStream ksIs = new FileInputStream(ksName);
                    ks.load(ksIs, ksPass);
                    KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
                    kmf.init(ks, ctPass);
                    SSLContext sc = SSLContext.getInstance(SSLContext.getDefault().toString());
                    sc.init(kmf.getKeyManagers(), null, null);
                    SSLServerSocketFactory sslServerSocketfactory = sc.getServerSocketFactory();

                    System.setProperty("javax.net.ssl.trustStore", "herong.jks");
                    System.setProperty("javax.net.ssl.keyStorePassword", "HerongJKS");

                    SSLServerSocket serverSock  = (SSLServerSocket) sslServerSocketfactory.createServerSocket(portint);

                    System.out.println("uddhav");
//                    EndRange.setVisible(true);
//                    StartRange.setVisible(true);
                    OutputTraditionalMethodTextArea.setVisible(true);
//                    CalculateFactorial.setVisible(true);
//                    Calculate.setVisible(true);
                    PortValue.setVisible(false);
//                    To.setVisible(true);
                    Listen.setVisible(false);

//                  listener for clients
                    SocketAcceptandListenerServer sat = new SocketAcceptandListenerServer(serverSock, OutputTraditionalMethodTextArea);
                    sat.start();
                } catch (KeyStoreException | NoSuchAlgorithmException | CertificateException | UnrecoverableKeyException | KeyManagementException ex) {
                    Logger.getLogger(BCSServer.class.getName()).log(Level.SEVERE, null, ex);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(BCSServer.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(BCSServer.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        }
    }//GEN-LAST:event_ListenActionPerformed

    private void EndRangePropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_EndRangePropertyChange
        // TODO add your handling code here:
    }//GEN-LAST:event_EndRangePropertyChange

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BCSServer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BCSServer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BCSServer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BCSServer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new BCSServer().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JButton Calculate;
    public static javax.swing.JLabel CalculateFactorial;
    public static javax.swing.JTextField EndRange;
    private javax.swing.JLabel FactorialResult;
    public static javax.swing.JButton Listen;
    private javax.swing.JScrollPane OutputScrollBar;
    public static javax.swing.JTextArea OutputTraditionalMethodTextArea;
    public static javax.swing.JTextField PortValue;
    public static javax.swing.JTextField StartRange;
    public static javax.swing.JLabel To;
    // End of variables declaration//GEN-END:variables

} //end
